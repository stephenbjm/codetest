package org.stephen.casumo.videorental.resources;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.stephen.casumo.videorental.model.Film;
import org.stephen.casumo.videorental.model.Rental;
import org.stephen.casumo.videorental.model.types.FilmType;
import org.stephen.casumo.videorental.service.RentalService;

@Path("/rentals")
@Consumes(MediaType.APPLICATION_JSON)	
@Produces(MediaType.APPLICATION_JSON)
public class RentalResource {
	
	RentalService rentalService = new RentalService();
	
	@GET
	public List<Rental> getRentals() {
		return rentalService.getAllRentals();
	}
	
	@GET
	@Path("/{rentalId}")
	public Rental getOneRental(@PathParam("rentalId") long rentalId) {
		return rentalService.getOneRental(rentalId);
	}
	
	@GET
	@Path("/cost/{rentalId}")
	@Produces(MediaType.TEXT_PLAIN)
	public int calculateRentalCost(@PathParam("rentalId") long rentalId) {
		Rental rental = rentalService.getOneRental(rentalId);
		Integer cost = 0;
		for (Film film : rental.getFilmList()) {
			cost += rental.getRentalNumberOfDays() * film.getPrice();
		}
		
		return cost;
	}
	
	@GET
	@Path("/{rentalId}/bonus")
	@Produces(MediaType.TEXT_PLAIN)
	public int calculateCustomerBonus(@PathParam("rentalId") long rentalId, Rental rental) {
		Integer bonus = 0;
/*		for (Film film : rental.getFilmList()) {
			if (film.getType() == FilmType.NEW) {
				bonus += 2;
			} else {
				bonus += 1;
			}
		}*/
		
		return bonus;
	}
	
	@POST
	public Rental addRental(Rental rental) {
		return rentalService.addRental(rental);
	}

	@PUT
	@Path("/{rentalId}")
	public Rental updateRental(@PathParam("rentalId") long rentalId, Rental rental) {
		rental.setId(rentalId);
		return rentalService.updateRental(rental);
	}
	
	@DELETE
	@Path("/{rentalId}")
	public void deleteRental(@PathParam("rentalId") long rentalId, Rental rental) {
		rental.setId(rentalId);
		rentalService.deleteRental(rental);
	}
}
