package org.stephen.casumo.videorental.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.stephen.casumo.videorental.DatabaseService.DatabaseService;
import org.stephen.casumo.videorental.model.Film;
import org.stephen.casumo.videorental.model.types.FilmType;

public class FilmService {
	
	private Map<Long, Film> films = DatabaseService.getFilms();
	
	public FilmService() {
		Film film1= new Film(1L, "Matrix 11", FilmType.NEW, 40);
		Film film2= new Film(2L, "Spider Man 1", FilmType.REGULAR, 30);
		Film film3= new Film(3L, "Spider Man 2", FilmType.REGULAR, 30);
		Film film4= new Film(4L, "Out of Africa", FilmType.OLD, 30);

		films.put(1L, film1);
		films.put(2L, film2);
		films.put(3L, film3);
		films.put(4L, film4);
	}

	public List<Film> getAllFilms() {
		return new ArrayList<Film>(films.values());
	}
	
	public Film getOneFilm(long id) {
		return films.get(id);		
	}
	
	public Film addFilm(Film film) {
		film.setId(films.size() + 1);
		films.put(film.getId(), film);
		return film;
	}
	
	public Film updateFilm(Film film) {
		if (film.getId() <= 0) {
			return null;
		}
		films.put(film.getId(), film);
		return film;
	}
	
	public Film deleteFilm(Film film) {
		return films.remove(film.getId());
	}
}
