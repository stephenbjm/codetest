package org.stephen.casumo.videorental.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Customer {
	
	private long id;
	private String firstName;
	private String lastName;
	private Integer bonusPoints;
	
	public Customer() {
	}

	public Customer(long id, String firstName, String lastName,
			Integer bonusPoints) {
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.bonusPoints = bonusPoints;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Integer getBonusPoints() {
		return bonusPoints;
	}

	public void setBonusPoints(Integer bonusPoints) {
		this.bonusPoints = bonusPoints;
	}
}
