package org.stephen.casumo.videorental.resources;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.stephen.casumo.videorental.model.Film;
import org.stephen.casumo.videorental.service.FilmService;

@Path("/films")
@Consumes(MediaType.APPLICATION_JSON)	
@Produces(MediaType.APPLICATION_JSON)
public class FilmResource {
	
	FilmService filmService = new FilmService();
	
	@GET
	public List<Film> getFilms() {
		return filmService.getAllFilms();
	}
	
	@GET
	@Path("/{filmId}")
	public Film getOneFilm(@PathParam("filmId") long filmId) {
		return filmService.getOneFilm(filmId);
	}
	
	@POST
	public Film addFilm(Film film) {
		return filmService.addFilm(film);
	}

	@PUT
	@Path("/{filmId}")
	public Film updateFilm(@PathParam("filmId") long filmId, Film film) {
		film.setId(filmId);
		return filmService.updateFilm(film);
	}
	
	@DELETE
	@Path("/{filmId}")
	public void deleteFilm(@PathParam("filmId") long filmId, Film film) {
		film.setId(filmId);
		filmService.deleteFilm(film);
	}
}
