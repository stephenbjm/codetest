package org.stephen.casumo.videorental.DatabaseService;

import java.util.HashMap;
import java.util.Map;

import org.stephen.casumo.videorental.model.Customer;
import org.stephen.casumo.videorental.model.Film;
import org.stephen.casumo.videorental.model.Rental;

public class DatabaseService {
	
	private static Map<Long, Customer> customers = new HashMap<>();
	private static Map<Long, Film> films = new HashMap<>();
	private static Map<Long, Rental> rentals = new HashMap<>();
	
	public static Map<Long, Customer> getCustomers() {
		return customers;
	}
	
	public static Map<Long, Film> getFilms() {
		return films;
	}
	
	public static Map<Long, Rental> getRentals() {
		return rentals;
	}
	
	
}
