package org.stephen.casumo.videorental.model;

import javax.xml.bind.annotation.XmlRootElement;

import org.stephen.casumo.videorental.model.types.FilmType;

@XmlRootElement
public class Film {
	
	private long id;
	private String title;
	private FilmType type;
	private Integer price;
	
	public Film() {
	}

	public Film(long id, String title, FilmType type, Integer price) {
		this.id = id;
		this.title = title;
		this.type = type;
		this.price = price;
	}
	
	public void setId(long id) {
		this.id = id;
	}

	public long getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public FilmType getType() {
		return type;
	}

	public void setType(FilmType type) {
		this.type = type;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}
}
