package org.stephen.casumo.videorental.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.stephen.casumo.videorental.DatabaseService.DatabaseService;
import org.stephen.casumo.videorental.model.Film;
import org.stephen.casumo.videorental.model.Rental;
import org.stephen.casumo.videorental.model.types.FilmType;

public class RentalService {
	
	private Map<Long, Rental> rentals = DatabaseService.getRentals();
	
	public RentalService() {
		List<Film> customer1FilmList = new ArrayList<Film>();
		// Customer 1 chooses 2 films:
		customer1FilmList.add(new Film(1L, "Matrix 11", FilmType.NEW, 40));
		customer1FilmList.add(new Film(2L, "Spider Man 1", FilmType.REGULAR, 30));
		
		Rental rental1= new Rental(1L, 1L, customer1FilmList, new Date(), 3); // 3-day rental of two films
		rentals.put(1L, rental1);
	}

	public List<Rental> getAllRentals() {
		return new ArrayList<Rental>(rentals.values());
	}
	
	public Rental getOneRental(long id) {
		return rentals.get(id);		
	}
	
	public Rental addRental(Rental rental) {
		rental.setId(rentals.size() + 1);
		rentals.put(rental.getId(), rental);
		return rental;
	}
	
	public Rental updateRental(Rental rental) {
		if (rental.getId() <= 0) {
			return null;
		}
		rentals.put(rental.getId(), rental);
		return rental;
	}
	
	public Rental deleteRental(Rental rental) {
		return rentals.remove(rental.getId());
	}
}
