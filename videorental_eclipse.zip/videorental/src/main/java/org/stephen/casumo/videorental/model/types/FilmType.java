package org.stephen.casumo.videorental.model.types;

public enum FilmType {
	NEW,
	REGULAR,
	OLD;
}
