package org.stephen.casumo.videorental.model;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Rental {
	
	private long id;
	private long customerId;
	private List<Film> filmList;
	private Date dateRented;
	private int rentalNumberOfDays;
	
	public Rental() {
	}

	public Rental(long id, long customerId, List<Film> filmList,
			Date dateRented, int rentalNumberOfDays) {
		this.id = id;
		this.customerId = customerId;
		this.filmList = filmList;
		this.dateRented = dateRented;
		this.rentalNumberOfDays = rentalNumberOfDays;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public List<Film> getFilmList() {
		return filmList;
	}

	public Date getDateRented() {
		return dateRented;
	}

	public void setDateRented(Date dateRented) {
		this.dateRented = dateRented;
	}

	public int getRentalNumberOfDays() {
		return rentalNumberOfDays;
	}

	public void setRentalNumberOfDays(int rentalNumberOfDays) {
		this.rentalNumberOfDays = rentalNumberOfDays;
	}
}
