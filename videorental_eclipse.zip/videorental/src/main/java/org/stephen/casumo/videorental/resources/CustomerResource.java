package org.stephen.casumo.videorental.resources;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.stephen.casumo.videorental.model.Customer;
import org.stephen.casumo.videorental.service.CustomerService;

@Path("/customers")
@Produces(MediaType.APPLICATION_JSON)
public class CustomerResource {
	
	CustomerService customerService = new CustomerService();
	
	@GET
	public List<Customer> getCustomers() {
		return customerService.getAllCustomers();
	}
}
