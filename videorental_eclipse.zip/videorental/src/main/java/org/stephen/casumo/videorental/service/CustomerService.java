package org.stephen.casumo.videorental.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.stephen.casumo.videorental.DatabaseService.DatabaseService;
import org.stephen.casumo.videorental.model.Customer;

public class CustomerService {
	
	private Map<Long, Customer> customers = DatabaseService.getCustomers();
	
	public CustomerService() {
		Customer customer1 = new Customer(1L, "Bob", "Marley", 0); // Bob has zero bonus to start
		
		customers.put(1L, customer1);
	}

	public List<Customer> getAllCustomers() {
		return new ArrayList<Customer>(customers.values());
	}
	
	public Customer getOneCustomer(long id) {
		return customers.get(id);		
	}
	
	public Customer addCustomer(Customer customer) {
		customer.setId(customers.size() + 1);
		customers.put(customer.getId(), customer);
		return customer;
	}
	
	public Customer updateCustomer(Customer customer) {
		if (customer.getId() <= 0) {
			return null;
		}
		customers.put(customer.getId(), customer);
		return customer;
	}
	
	public Customer deleteCustomer(Customer customer) {
		return customers.remove(customer.getId());
	}
}
